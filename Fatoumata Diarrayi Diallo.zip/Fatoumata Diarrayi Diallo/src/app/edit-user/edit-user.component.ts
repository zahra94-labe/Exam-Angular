import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Params } from '@angular/router';
import { UserService } from '../services/users/user.service';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {

  USER: any;
 userEdit: any;
  constructor(private activerRoute: ActivatedRoute, private userService: UserService) { }

  ngOnInit(): void {
    this.activerRoute.params.subscribe(
      (params: Params)=>{
        this.USER=params.id;
        this.userService.getOneUsers(+this.USER).subscribe(
          data =>{
            this.userEdit = data;
            console.log(data)
          }
        )
        
      }
    )
  }
  Editer(formulaire: NgForm){
    this.userService.update(this.USER,formulaire.value).subscribe(
      data =>{
        alert("modification effectué")
      },
      error=>{
        alert("erreur sur modifier")
      }
    )
    console.log(formulaire.value)
  }

}
