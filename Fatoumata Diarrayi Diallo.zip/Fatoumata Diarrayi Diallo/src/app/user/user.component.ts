import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { UserService } from '../services/users/user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  dtOptions: DataTables.Settings= {};
  dtTrigger: Subject<any> = new Subject();
  user : any;
  constructor(private userService: UserService) { }
 
  ngOnInit(): void {
    this.userService.refresh.subscribe(
      ()=>{
        this.chargerTable();
      }
    )
    this.dtOptions={
      pagingType: 'full_numbers',
      pageLength: 5,
      autoWidth: true,//autosize colum
      order: [[0, 'desc']],
      lengthMenu:[3,5,10]
    };
    
    this.chargerTable();
  }
  chargerTable(){
    this.userService.getAllUsers().subscribe(
      donnee=>{
        this.user=donnee;
        this.dtTrigger.next();
        
        console.log(donnee);
      },
      erreur=>{
        console.log(erreur);
      }
    );
  }
  delete(id: number){
    this.userService.deleteOneUsers(id).subscribe(
      donnee=>{
        alert("Supprimer avec succès");
        console.log(donnee);
      },
      erreur=>{
        alert("Erreur sur supprimer");
        console.log(erreur);
      }
    );

  }

}
