import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Params } from '@angular/router';
import { CommentaireService } from '../services/commentaires/commentaire.service';

@Component({
  selector: 'app-edit-comment',
  templateUrl: './edit-comment.component.html',
  styleUrls: ['./edit-comment.component.css']
})
export class EditCommentComponent implements OnInit {

  USER: any;
  commentEdit: any;
   constructor(private activerRoute: ActivatedRoute, private commentSer: CommentaireService) { }
 
   ngOnInit(): void {
     this.activerRoute.params.subscribe(
       (params: Params)=>{
         this.USER=params.id;
         this.commentSer.getOneCommentaires(+this.USER).subscribe(
           data =>{
             this.commentEdit = data;
             console.log(data)
           }
         )
         
       }
     )
   }
   Editer(formulaire: NgForm){
     this.commentSer.update(this.USER,formulaire.value).subscribe(
       data =>{
         alert("modification effectué")
       },
       error=>{
         alert("erreur sur modifier")
       }
     )
     console.log(formulaire.value)
   }
 
}
