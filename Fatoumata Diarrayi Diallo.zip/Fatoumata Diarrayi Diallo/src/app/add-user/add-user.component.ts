import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../services/users/user.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  constructor(private userService: UserService) { }

  ngOnInit(): void {
  
  }
  ajouter(formulaire: NgForm){
    this.userService.addUsers(formulaire.value).subscribe(
      data =>{
        alert("ajout effectué")
      },
      error=>{
        alert("erreur sur ajout")
      }
    )
    console.log(formulaire.value)
  }


}
