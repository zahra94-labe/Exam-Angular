import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CommentaireService } from '../services/commentaires/commentaire.service';

@Component({
  selector: 'app-add-comment',
  templateUrl: './add-comment.component.html',
  styleUrls: ['./add-comment.component.css']
})
export class AddCommentComponent implements OnInit {

  constructor(private commentService: CommentaireService) { }

  ngOnInit(): void {
  
  }
  ajouter(formulaire: NgForm){
    this.commentService.addCommentaires(formulaire.value).subscribe(
      data =>{
        alert("ajout effectué")
      },
      error=>{
        alert("erreur sur ajout")
      }
    )
    console.log(formulaire.value)
  }


}
