import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddCommentComponent } from './add-comment/add-comment.component';
import { AddUserComponent } from './add-user/add-user.component';
import { AjoutPostComponent } from './ajout-post/ajout-post.component';
import { CommentaireComponent } from './commentaire/commentaire.component';
import { EditCommentComponent } from './edit-comment/edit-comment.component';
import { EditPostComponent } from './edit-post/edit-post.component';
import { EditUserComponent } from './edit-user/edit-user.component';
import { PosterComponent } from './poster/poster.component';
import { UserComponent } from './user/user.component';

const routes: Routes = [
  {path:'poster', component: PosterComponent},
  {path:'commenter', component: CommentaireComponent},
  {path:'utilisateur', component: UserComponent},
  {path:'posteEdit/:id', component: EditPostComponent},
  {path:'commentEdit/:id', component: EditCommentComponent},
  {path:'userEdit/:id', component: EditUserComponent},
  {path:'addpost', component: AjoutPostComponent},
  {path:'addComment', component: AddCommentComponent},
  {path:'addUser', component: AddUserComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
